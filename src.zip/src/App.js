import React from 'react';
//import {Route} from 'react-router-dom';
import {Container} from 'react-bootstrap';
import Header from './components/Header';
import Reservationslist from './components/Reservationslist';
//import ReserveAcubicle from './components/ReseveAcubicle';
import { BrowserRouter, Route, Switch } from "react-router-dom";
import CancelReservation from './components/CancelReservation';
//import Logout from './components/Logout';


function App() {
  return (
    <div>
    <Header/>
    <Container>
    <Route path = "/" exact={true} component={Reservationslist} />
    <Route path = "/Cancel Reservation" exact={true} component={CancelReservation} />
    <Route path="/add-reservation" exact component={CancelReservation}></Route>
   <Route path="/update/:id" component={CancelReservation}></Route>
    <Route path="/delete/:id" component={CancelReservation}></Route>

    </Container>
    </div>
  )
}

export default App;
    


      


