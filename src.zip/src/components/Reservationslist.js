import React, { Component } from "react";
import axios from "axios";
import { withRouter } from 'react-router';
import { Link } from 'react-router-dom'

class Reservationslist extends Component {
    state = { reservations: [] }
   

    componentDidMount() {
        axios.get("http://localhost:8080/").then((res) => {
            this.setState({ reservations: res.data })
        })
    }
    onClick = () => {

        this.props.history.push("/http://localhost:3000/#ReserveACubicle")
    }
   
    render() {
        return (
            <div>
                <h2 className="text-left">
                    Reservations List
                </h2>
                <div className="btn-right">
                    <button type="button" className="btn btn-primary " onClick={this.onClick}>Add New Reservation</button>
                </div>
                
                <div>&nbsp;</div>
                <div className="row">
                    <table className="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>Reservation ID</th>
                                <th> Name</th>
                                <th>Cubicle Number</th>
                                <th> Start Date</th>
                                <th>End date</th>
                                <th>Arrival time</th>
                                <th>Departure Time</th>
                            </tr>

                        </thead>
                        <tbody>
                            {
                                this.state.reservations.map(reservation => {
                                    return (
                                        <tr key={reservation.id}reservation = {reservation}>
                                            <td>{reservation.revId}</td>
                                            <td>{reservation.name}</td>
                                            <td>{reservation.cubicle}</td>
                                            <td>{reservation.startDate}</td>
                                            <td>{reservation.endDate}</td>
                                            <td>{reservation.arrivalTime}</td>
                                            <td>{reservation.departureTime}</td>
                                            <td>
                                            
                                                <button type="button" className="btn btn-outline-success btn-sm"><Link to={`/update/${reservation.id}`}>Update</Link></button>
                                                <button type="button" className="btn btn-outline-danger btn-sm" ><Link to={`/delete/${reservation.id}`}>Delete</Link></button>
                                            </td>
                                        </tr>)


                                })
                            }
                        </tbody>
                    </table>
                </div>
            </div >
        )
    }
}

export default withRouter(Reservationslist)