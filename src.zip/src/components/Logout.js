import React from 'react'

const myAccount = () => {
    return (
        <div>
            My Account
        </div>
    )
}
export default myAccount
