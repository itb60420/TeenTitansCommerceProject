import React, { Component } from "react";
import axios from "axios";
import { withRouter } from 'react-router';

class CancelReservation extends Component {
    state = {
        revId: '',
        name: '',
        cubicle: '',
        startDate: '',
        endDate: '',
        arrivalTime: '',
        departureTime: ''
      
    }
    componentDidMount() {
        if (this.props.match.path === "/update/:id") {
            axios.get("http://localhost:8080/" + this.props.match.params.id).then(
                (res) => {
                    this.setState({ revId: res.data.revId, name: res.data.name, cubicle: res.data.cubicle, startDate: res.data.startDate,
                        endDate: res.data.endDate, arrivalTime: res.data.arrivalTime, departureTime: res.data.departureTime, })

                }
            ).catch(error => {
                console.log(error.message)
            })

        }
        else if (this.props.match.path === "/delete/:id") {
            axios.delete("http://localhost:8080/" + this.props.match.params.id, this.state).then(
                (res) => {
                    this.props.history.push("/reservations")

                }
            ).catch(error => {
                console.log(error.message)
            })
        }


    }
  /*  onrevIdChange = (revId) => {
        console.log("changing the input")
        this.setState({ revId: revId.target.value })
    }

    onnameChange = (name) => {
        console.log("changing the input1")
        this.setState({ name: name.target.value })
    }
    oncubicleChange = (cubicle) => {
        console.log("changing the input2")
        this.setState({ cubicle: cubicle.target.value })
    }
    onstartDateChange = (startDate) => {
        console.log("changing the input")
        this.setState({ startDate: startDate.target.value })
    }
    onendDateChange = (endDate) => {
        console.log("changing the input")
        this.setState({ endDate: endDate.target.value })
    }
    onarrivalTimeChange = (arrivalTime) => {
        console.log("changing the input")
        this.setState({ arrivalTime: arrivalTime.target.value })
    }
    ondepartureTimeChange = (departureTime) => {
        console.log("changing the input")
        this.setState({ departureTime: departureTime.target.value })
    }
    */






    addReservation = (r) => {
        r.preventDefault()
        console.log(this.props.match.path)
        if (this.props.match.path === "/update/:id") {
            console.log("entered in update")
            axios.put("/" + this.props.match.params.id, this.state).then(
                (res) => {
                    this.props.history.push("/")

                }
            ).catch(error => {
                console.log(error.message)
            })
        }

        else {
            axios.post("http://localhost:8080/", this.state).then(
                (res) => {
                    console.log(this.props.history)
                    this.props.history.push("/")
                }
            ).catch(error => {
                console.log(error.message)
            })
        }


    }

    CancelReservation = () => {
        this.props.history.push("/")
    }
    render() {
        return (
            <div>
                <div className="container">
                    <div className="row">
                        <div className="card col-md-6 offset-md-3 offset-md-3">
                            <h3 className="text-center">Add Employee</h3>
                            <div className="card-body">
                                <form>
                                    <div className="form-group">
                                        <label htmlFor="name" className="text-left">Name</label>
                                        <input id="Name" placeholder="Enter Name" value={this.state.name}
                                            className="form-control" onChange={this.onnameChange} type="text" ></input>

                                        <label htmlFor="cubicle">Cubicle</label>
                                        <input id="cubicle" placeholder="Enter the cubicle" value={this.state.cubicle}
                                            className="form-control" onChange={this.oncubicleChange} type="text" ></input>
                                        <label htmlFor="id">Reservation Id</label>
                                        <input id="revId" placeholder="Enter the id" value={this.state.revId}
                                            className="form-control" onChange={this.onrevIdChange} type="text" ></input>
                                    </div>

                                    <div>
                                        <button type="button" className="btn btn-outline-success btn-sm m-2" onClick={this.addReservation} >Submit</button>
                                        <button type="button" onClick={this.CancelReservation} className="btn btn-outline-danger btn-sm">Cancel</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div >
        )
    }
}

export default withRouter(CancelReservation)