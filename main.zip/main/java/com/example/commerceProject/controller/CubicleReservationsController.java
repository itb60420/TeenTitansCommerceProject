package com.example.commerceProject.controller;

import com.example.commerceProject.domain.CubicleReservations;
import com.example.commerceProject.service.CubicleReservationsService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.commerceProject.repository.CubicleReservationsRepository;

import java.sql.Timestamp;
import java.util.List;

@CrossOrigin(origins = "http://localhost:3000")
@RequiredArgsConstructor
@RestController
public class CubicleReservationsController {

    @Autowired
    private final CubicleReservationsService cubicleReservationsService;

    @CrossOrigin
    @PostMapping("/reservation/submit") //create cubicle reservation
    public ResponseEntity<?> save(@RequestBody CubicleReservations cubicleReservations){
        return new ResponseEntity<>(cubicleReservationsService.create(cubicleReservations), HttpStatus.CREATED);
    }

    @CrossOrigin
    @GetMapping("/amap") //find all cubicle reservations - shouldn't be used; left in just in case
    public ResponseEntity<?> findAll(){
        return new ResponseEntity<>(cubicleReservationsService.findAll(), HttpStatus.OK);
    }

    @CrossOrigin
    @GetMapping("/reservation/user/{id}") //find cubicle reservation by user id
    public ResponseEntity<?> findByUserId(@PathVariable Long id){
        return new ResponseEntity<>(cubicleReservationsService.findResByUserId(id), HttpStatus.OK);
    }

    @CrossOrigin
    @GetMapping("/reservation/{id}") //find cubicle reservation by reservation id
    public ResponseEntity<?> findByResId(@PathVariable Long id){
        return new ResponseEntity<>(cubicleReservationsService.findResByResId(id), HttpStatus.OK);
    }

    @CrossOrigin
    @GetMapping("reservation/update") //find cubicle availability
    public ResponseEntity<?> findByAvailability(@RequestParam String start, @RequestParam String end) {
        Timestamp reservationStart = new Timestamp(Long.parseLong(start));
        Timestamp reservationEnd = new Timestamp(Long.parseLong(end));
        return new ResponseEntity<>(cubicleReservationsService.findCubiclesByAvailability(reservationStart, reservationEnd), HttpStatus.OK);
    }

    @CrossOrigin
    @PutMapping("/edit/{id}") //update cubicle reservation
    public ResponseEntity<?> update(@PathVariable Long id, @RequestBody CubicleReservations cubicleReservations){
        return new ResponseEntity<>(cubicleReservationsService.update(id, cubicleReservations), HttpStatus.OK);
    }

    @CrossOrigin
    @DeleteMapping("/cancel/{id}") //delete cubicle reservation
    public ResponseEntity<?> deleteById(@PathVariable Long id){
        return new ResponseEntity<>(cubicleReservationsService.delete(id), HttpStatus.OK);
    }
}