package com.example.commerceProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommerceProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommerceProjectApplication.class, args);
	}

}
