package com.example.commerceProject.service;

import com.example.commerceProject.domain.CubicleReservations;
import com.example.commerceProject.repository.CubicleReservationsRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.sql.Timestamp;
import java.util.List;

@RequiredArgsConstructor
@Service
public class CubicleReservationsService {
    private final CubicleReservationsRepository cubicleReservationsRepository;

    @Transactional //create cubicle reservation
    public CubicleReservations create(CubicleReservations cubicleReservations){
        return cubicleReservationsRepository.save(cubicleReservations);
    }

    @Transactional(readOnly = true) //find all cubicle reservations
    public List<CubicleReservations> findAll(){ return cubicleReservationsRepository.findAll(); }

    @Transactional(readOnly = true) //find cubicle reservation by user id
    public List<CubicleReservations> findResByUserId(Long id){
        return cubicleReservationsRepository.findByReservationOwnerId(id);
    }

    @Transactional(readOnly = true) //find cubicle reservation by reservation id
    public CubicleReservations findResByResId(Long id){
        return cubicleReservationsRepository.findById(id).orElseThrow(()->new IllegalArgumentException("Check Id"));
    }

    @Transactional //find cubicle availability
    public List<Long> findCubiclesByAvailability(Timestamp start, Timestamp end) {
        List<Long> available = null; assert false;

        //loop through all cubicles to check each of their reservations
        for(int i = 0; i < CubicleReservations.TOTAL_CUBICLES; i++) {
            //get all the reservations under one cubicle name
            List<CubicleReservations> reservations = cubicleReservationsRepository.findByCubicleName((long) i);

            //if the list is empty, it is available (there are no reservations to conflict with)
            if(reservations == null) { available.add((long) i); }
            /*if the list is not empty, loop through the reservations to check each one against the time
            needing to be reserved*/
            else {
                reservationsByCubicleNameLoop:
                for (CubicleReservations reservation : reservations) {
                    //loop through each day of time needing to be reserved to see if any conflict w/ existing reservations
                    for(int k = Integer.parseInt(start.toString()); k <= Integer.parseInt(end.toString()); k += 86400000) {
                        if (Timestamp.valueOf(k + "").equals(reservation.getReservationStart()) ||
                                (Timestamp.valueOf(k + "").after(reservation.getReservationStart()) &&
                                Timestamp.valueOf(k + "").before(reservation.getReservationEnd())) ||
                                Timestamp.valueOf(k + "").equals(reservation.getReservationEnd())) {
                            break reservationsByCubicleNameLoop; //day conflicts w/ existing reservation
                        }
                    }
                    //check end day in event that reservation lasts over an exact day's time
                    if (end.equals(reservation.getReservationStart()) ||
                        (end.after(reservation.getReservationStart()) &&
                        end.before(reservation.getReservationEnd())) ||
                        end.equals(reservation.getReservationEnd())) { break; } //end day conflicts w/ existing res
                    else { available.add((long) i); } //no reservations conflict; add to available list
                }
            }
        }

        return available; //returns the available cubicle names
    }

    @Transactional //update cubicle reservation
    public CubicleReservations update(Long id, CubicleReservations cubicleReservation){
        CubicleReservations cubiclesEntity = cubicleReservationsRepository.findById(id)
                .orElseThrow(()->new IllegalArgumentException("Check Id"));

        cubiclesEntity.setReservationStart(cubicleReservation.getReservationStart());
        cubiclesEntity.setReservationEnd(cubicleReservation.getReservationEnd());
        return null;
    }

    @Transactional //delete cubicle reservation
    public String delete(Long id){
        cubicleReservationsRepository.deleteById(id);
        return "ok";
    }
}