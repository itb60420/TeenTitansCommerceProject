package com.example.commerceProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommerceProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
