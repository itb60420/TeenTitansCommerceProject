import React, { Component } from "react";
import axios from "axios";
import { withRouter } from 'react-router';

class CancelReservation extends Component {
    state = {
        revId: '',
        name: '',
        cubicle: '',
        startDate: '',
        endDate: '',
        arrivalTime: '',
        departureTime: ''
      
    }
    componentDidMount() {
        if (this.props.match.path === "/update/:id") {
            axios.get("http://localhost:8080/" + this.props.match.params.id).then(
                (res) => {
                    this.setState({ revId: res.data.revId, name: res.data.name, cubicle: res.data.cubicle, startDate: res.data.startDate,
                        endDate: res.data.endDate, arrivalTime: res.data.arrivalTime, departureTime: res.data.departureTime, })

                }
            ).catch(error => {
                console.log(error.message)
            })

        }
        else if (this.props.match.path === "/delete/:id") {
            axios.delete("http://localhost:8080/" + this.props.match.params.id, this.state).then(
                (res) => {
                    this.props.history.push("/reservations")

                }
            ).catch(error => {
                console.log(error.message)
            })
        }


    }




    addReservation = (r) => {
        r.preventDefault()
        console.log(this.props.match.path)
        if (this.props.match.path === "/update/:id") {
            console.log("entered in update")
            axios.put("/" + this.props.match.params.id, this.state).then(
                (res) => {
                    this.props.history.push("/")

                }
            ).catch(error => {
                console.log(error.message)
            })
        }

        else {
            axios.post("http://localhost:8080/", this.state).then(
                (res) => {
                    console.log(this.props.history)
                    this.props.history.push("/")
                }
            ).catch(error => {
                console.log(error.message)
            })
        }


    }

    CancelReservation = () => {
        this.props.history.push("/")
    }
  
}

export default withRouter(CancelReservation)