import React, {Component} from "react";
import Reservationslist from "../reservation/Reservationslist";
import {Link, BrowserRouter as  Router, Route, Switch} from 'react-router-dom';

export default class Login extends Component{

    render() {
        return (
        <body>
        <div class="bck-image">
            <form action="/action_page.php" class="box">
            <h1>Commerce Bank</h1> <b></b> <h1> Reserve A Cubicle</h1>
                <label for="email"><b></b></label>
                <input class="inemail"type="text" placeholder="Enter email" name="email" required />

                <label for="psw"><b></b></label>
                <input class="inpsw" type="password" placeholder="Enter Password" name="psw" required />

                <Link to="/ReserveACubicle">
                <button class="SignBtn">Sign In</button> </Link>
                    
            </form>
            </div>
        </body>

        );

    }

}